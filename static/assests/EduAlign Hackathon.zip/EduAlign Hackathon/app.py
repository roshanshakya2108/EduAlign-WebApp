from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)

# Load the model
model = joblib.load('school_needs_model.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    # Process input features and make prediction
    prediction = model.predict([data['features']])
    return jsonify({'necessities_required': prediction[0]})

if __name__ == '__main__':
    app.run(debug=True)
