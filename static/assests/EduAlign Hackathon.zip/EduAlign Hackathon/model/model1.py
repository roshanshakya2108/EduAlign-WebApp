import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load your dataset
df = pd.read_excel('updated_indian_school_survey_data.xlsx')

# Feature columns
X = df[['Number of Teachers', 'Number of Students', 'Urban/Rural', 'School Types', 'Is there science lab facilities available in the school?', 'Is there any Computer lab facilities available in the school?']]

# Convert categorical features to numerical values (if necessary)
X = pd.get_dummies(X)

# Target column (Necessities required)
y = df['Necessities required']

# Split into train/test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a model (RandomForest in this example)
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model accuracy: {accuracy}")

# Save the model
import joblib
joblib.dump(model, 'school_needs_model.pkl')
